# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module for Assignment Management System
# ----------------------------------------------------------

from . import models
from . import wizard
