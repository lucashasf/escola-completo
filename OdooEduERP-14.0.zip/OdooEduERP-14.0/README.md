[![Build Status](https://travis-ci.org/JayVora-SerpentCS/OdooEduERP.svg?branch=14.0)](https://travis-ci.org/JayVora-SerpentCS/OdooEduERP)

# EduERPv14
Education ERP v14
Serpent Consulting Services Pvt Ltd, the Official Odoo GOLD partner has here contributed the Education ERP.

Help us do better by donating to us and motivating us : http://www.serpentcs.com/page/donate-to-serpentcs
Thanks.
